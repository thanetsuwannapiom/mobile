package com.example.sqlkp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
